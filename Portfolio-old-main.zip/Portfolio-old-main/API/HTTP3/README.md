# HTTP/3
These projects feature an ASP.NET Core .NET 7 Server and a .NET 7 Console Client.
The ASP.NET Core HTTP/3 Server requires a developer certificate to run in the debugger.
If you'd like to host this, it requires a non self-signed certificate.
# Reverse Proxy
When using a reverse proxy, make sure to setup Forwarded Headers
